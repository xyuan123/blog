# Issue

- [ ] I have alreday read instructions in [CONTRIBUTING](CONTRIBUTING.md).
  我已仔细阅读[CONTRIBUTING](CONTRIBUTING.md)中的相关内容。

- [ ] I have alreday read instructions in [README](../README.md).
  我已仔细阅读[README](../README.md)中的相关内容。

> Change the `[ ]` into `[x]` to show my acceptance.
将 `[ ]` 变为 `[x]` 来表示我接受了这些问题。

@xiazeyu @EYHN
